	<!-- Kết nối thư viện Jquery -->
	<script src="js/jquery.js"></script>
	<!-- Kết nối file js/join.js -->
	<script src="js/join.js"></script>
	<!-- Kết nối file js/sendmsg.js -->
	<script src="js/sendmsg.js"></script>
	<!-- Kết nối file js/autoload.js -->
	<script src="js/autoload.js"></script>
</body>
</html>

