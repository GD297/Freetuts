<?php
	// Kết nối database, lấy dữ liệu chung
	include('includes/general.php');
	// Kết nối header
	include('includes/header.php');
        // Kết nối footer
	include('includes/footer.php');
?>

