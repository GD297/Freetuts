<?php
  require('Pusher.php');

  $options = array(
    'encrypted' => true
  );
  $pusher = new Pusher(
  '10d5ea7e7b632db09c72',
    'a496a6f084ba9c65fffb',
    '234217',
    $options
  );
  $data['name'] = 'Freetuts';
  $data['message'] = 'Đây là tin nhắn test realtime với pusher';
  $pusher->trigger('Freetuts', 'notice', $data);
  //trong do
//Freetuts la ten kenh ban dat la gi thuy
  //notice la su kien ban dat gi cung duoc ban co the tao ra nhieu kenh
  //data la du lieu gui di
?>