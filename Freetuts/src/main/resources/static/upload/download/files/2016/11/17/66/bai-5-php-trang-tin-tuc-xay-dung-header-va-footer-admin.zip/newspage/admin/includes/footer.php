	<!-- Liên kết thư viện jQuery Form -->
	<script src="<?php echo $_DOMAIN; ?>js/jquery.form.min.js"></script>	
</body>
</html>