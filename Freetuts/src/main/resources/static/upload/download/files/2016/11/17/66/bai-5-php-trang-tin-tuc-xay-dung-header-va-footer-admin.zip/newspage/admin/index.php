<?php

// Require database & thông tin chung
require_once 'core/init.php';

// Require header
require_once 'includes/header.php';

// Require footer
require_once 'includes/footer.php';

?>