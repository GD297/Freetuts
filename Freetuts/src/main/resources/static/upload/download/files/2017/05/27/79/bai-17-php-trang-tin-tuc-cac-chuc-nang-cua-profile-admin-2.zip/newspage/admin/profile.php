<?php

// Kết nối database và thông tin chung
require_once 'core/init.php';

// Nếu đăng nhập
if ($user) 
{
	// Nếu có file upload
	if (isset($_FILES['img_avt'])) 
	{
		$dir = "../upload/"; 
		$name_img = stripslashes($_FILES['img_avt']['name']);
		$source_img = $_FILES['img_avt']['tmp_name'];

		// Lấy ngày, tháng, năm hiện tại
		$day_current = substr($date_current, 8, 2);
		$month_current = substr($date_current, 5, 2);
		$year_current = substr($date_current, 0, 4);

		// Tạo folder năm hiện tại
		if (!is_dir($dir.$year_current))
		{
    		mkdir($dir.$year_current.'/');
		} 

		// Tạo folder tháng hiện tại
		if (!is_dir($dir.$year_current.'/'.$month_current))
    	{
    		mkdir($dir.$year_current.'/'.$month_current.'/');
    	}	

    	// Tạo folder ngày hiện tại
    	if (!is_dir($dir.$year_current.'/'.$month_current.'/'.$day_current))
	    {
	    	mkdir($dir.$year_current.'/'.$month_current.'/'.$day_current.'/');
	    }

		$path_img = $dir.$year_current.'/'.$month_current.'/'.$day_current.'/'.$name_img; // Đường dẫn thư mục chứa file
		move_uploaded_file($source_img, $path_img); // Upload file
		$url_img = substr($path_img, 3); // Đường dẫn file

		$sql_up_avt = "UPDATE accounts SET url_avatar = '$url_img' WHERE id_acc = '$data_user[id_acc]'";
		$db->query($sql_up_avt);
		echo 'Upload thành công.';
		$db->close();
		new Redirect($_DOMAIN.'profile');
	} 
	// Nếu tồn tại POST action
	else if (isset($_POST['action']))
	{
		$action = trim(addslashes(htmlspecialchars($_POST['action'])));

		// Xoá ảnh đại diện
		if ($action == 'delete_avt')
		{		
			if (file_exists('../'.$data_user['url_avatar']))
			{
				unlink('../'.$data_user['url_avatar']);
			}

			$sql_delete_avt = "UPDATE accounts SET url_avatar = '' WHERE id_acc = '$data_user[id_acc]'";
			$db->query($sql_delete_avt);
			$db->close();	
		}
	}
	else
	{
		new Redirect($_DOMAIN); 
	}
}
// Ngược lại chưa đăng nhập
else
{
    new Redirect($_DOMAIN); // Trở về trang index
}
 
?>