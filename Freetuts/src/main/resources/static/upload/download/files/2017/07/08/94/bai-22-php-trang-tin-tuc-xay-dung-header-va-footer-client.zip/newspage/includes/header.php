<?php

$title_error_404 = 'Không tìm thấy trang';

// Url bài viết
if (isset($_GET['sp']) && isset($_GET['id'])) {
	$slug_post = trim(htmlspecialchars($_GET['sp']));
	$id_post = trim(htmlspecialchars($_GET['id']));

	// Kiểm tra bài viết tồn tại
	$sql_check_post = "SELECT id_post, slug, title FROM posts WHERE slug = '$slug_post' AND id_post = '$id_post'";
	if ($db->num_rows($sql_check_post)) {
		$data_post = $db->fetch_assoc($sql_check_post, 1);

		$title = $data_post['title'];
		// ...
	} else {
		$title = $title_error_404;
		// ...
	}
// Url chuyên mục
} else if (isset($_GET['sc'])) {
	$slug_cate = trim(htmlspecialchars($_GET['sc']));

	// Kiểm tra chuyên mục tồn tại
	$sql_check_cate = "SELECT url, label FROM categories WHERE url = '$slug_cate'";
	if ($db->num_rows($sql_check_cate)) {
		$data_cate = $db->fetch_assoc($sql_check_cate, 1);

		$title = $data_cate['label'];
		// ...
	} else {
		$title = $title_error_404;
		// ...
	}
} else {
	$title = $data_web['title'];
	// ...
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title><?php echo $title; ?></title>
		<!-- ... -->

		<link rel="stylesheet" href="<?php echo $_DOMAIN; ?>admin/bootstrap/css/bootstrap.min.css">
	</head>
	<body>
