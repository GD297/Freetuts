<?php

if (empty($s)) {
	echo 'Vui lòng nhập từ khóa tìm kiếm.';
} else {
	echo 1;
}

?>